package net.skhu.entity;

public class Customer {

}

package net.skhu.repository;

public interface ProductRepository {

}

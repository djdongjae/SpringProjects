package net.skhu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.skhu.entity.Engineer;
import net.skhu.repository.EngineerRepository;
import net.skhu.repository.RoleRepository;

@RestController
public class EngineerController {
	
	@Autowired EngineerRepository engineerRepository;
    @Autowired RoleRepository roleRepository;
    
    @RequestMapping("exam1")
    public List<Engineer> exam1() {
        return engineerRepository.findAll();
    }
    
    @RequestMapping("exam2")
    public List<Engineer> exam2(int id) {
    	return engineerRepository.findByRoleId(id);
    }
    
    @RequestMapping("exam3")
    public List<Engineer> exam3(String name) {
    	return engineerRepository.findByName(name);
    }
    
    

}

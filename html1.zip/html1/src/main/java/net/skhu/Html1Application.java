package net.skhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Html1Application {

	public static void main(String[] args) {
		SpringApplication.run(Html1Application.class, args);
	}

}

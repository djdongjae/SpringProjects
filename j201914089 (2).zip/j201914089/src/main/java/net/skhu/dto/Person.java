package net.skhu.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
public class Person {
	int pid;
	
	@NotEmpty
	@NotBlank
	String name;
	
	@NotEmpty
	@NotBlank
	int categoryCode;	
	
	String phone;
	
	@NotEmpty
	@NotBlank
	@Email
	String email;
	
	String gender;
	
	@NotEmpty
	@NotBlank
	String title;
	
	String categoryTitle;

}

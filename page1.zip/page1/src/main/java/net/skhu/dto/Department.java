package net.skhu.dto;

import lombok.Data;

@Data
public class Department {
    int id;
    String name;
}


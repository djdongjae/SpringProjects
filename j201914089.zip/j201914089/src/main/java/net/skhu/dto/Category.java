package net.skhu.dto;

import lombok.Data;

@Data
public class Category {
	
	int code;
	String title;

}
